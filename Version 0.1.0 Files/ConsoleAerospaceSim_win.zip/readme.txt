Version 0.1 ig

its not a virus lol
anyways i'd like to thank Wikipedia, the space and math stack exchanges, stack overflow, and desmos

next imma try to add a payload creation system w/ mass, delta-V, Isp, etc. (NOT ROCKET SO IT STARTS IN ORBIT (aka much easier)) 
almost half the code is from `public static void OrbitalBurn(Stopwatch stopwatch)` lol, thats what makes the burn function possible

405 lines, almost 14000 characters, almost 1200 words, 20 code comments, ~30 variables, and 778 uses of the letter 'e'

Patch 0.1.1: Fixed some formatting issues, and removed save and load options.